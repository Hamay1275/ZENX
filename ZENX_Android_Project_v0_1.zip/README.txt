ZENX Android starter project (v0.1)

This is Android source code, NOT a compiled APK.

What currently works in this starter:
- Native Android app shell and saved game list
- URL input and basic file-extension detection
- Android DownloadManager for direct file URLs
- In-app WebView for ordinary web pages
- EXE compatibility warning

Important limitations:
- MediaFire/MEGA/Drive share pages are not necessarily direct file URLs. This starter opens those pages in the in-app browser; it does not bypass host pages, waiting rooms, ads, permissions, or access controls.
- A filename-based guess is not reliable game-name recognition.
- EXE files do not run natively on Android. A separate compatible Windows-emulation environment is required.
- ZIP/JAR/ISO files are downloaded but not automatically installed/launched.
- APK installation requires Android's user-controlled package installer and appropriate permission/settings.
- To build: open this folder in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
