package com.zenx.launcher

import android.app.*
import android.os.Bundle
import android.os.Environment
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.webkit.*
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var urlBox: EditText
    private lateinit var list: LinearLayout
    private val prefs by lazy { getSharedPreferences("zenx", MODE_PRIVATE) }
    private val items = JSONArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,21,34)
        window.navigationBarColor = Color.rgb(16,21,34)
        buildUi()
        loadItems()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(Color.rgb(16,21,34))
        }
        val title = TextView(this).apply {
            text = "ZENX"
            textSize = 32f
            setTextColor(Color.rgb(190,160,255))
            setTypeface(null, 1)
        }
        root.addView(title)
        root.addView(label("YOUR GAME LIBRARY", 13f, Color.LTGRAY))
        urlBox = EditText(this).apply {
            hint = "Paste a game or website URL"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setSingleLine(true)
            setPadding(16, 12, 16, 12)
            setBackgroundColor(Color.rgb(35,43,62))
        }
        root.addView(urlBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 18 })
        val add = Button(this).apply {
            text = "CHECK LINK / ADD GAME"
            setOnClickListener { checkLink() }
        }
        root.addView(add, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 18 })
        setContentView(root)
    }

    private fun label(s: String, size: Float, color: Int) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); setPadding(0, 8, 0, 8)
    }

    private fun checkLink() {
        val raw = urlBox.text.toString().trim()
        if (raw.isEmpty()) { toast("Paste a link first"); return }
        val normalized = if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "https://$raw"
        val uri = try { Uri.parse(normalized); URL(normalized); Uri.parse(normalized) }
                  catch (_: Exception) { toast("That link doesn't look valid"); return }
        val host = uri.host ?: ""
        val path = uri.path ?: ""
        val ext = path.substringAfterLast('.', "").lowercase()
        val knownFile = ext in listOf("apk","exe","zip","jar","iso","7z","rar","xapk","apks")
        val name = path.substringAfterLast('/').takeIf { it.isNotBlank() } ?: host
        if (!knownFile && (host.contains("mediafire") || host.contains("drive.google") ||
                host.contains("mega.nz") || host.contains("dropbox"))) {
            showWebPage(normalized)
            return
        }
        if (!knownFile && (ext.isBlank() || ext !in listOf("html","htm","php","asp","aspx"))) {
            showWebPage(normalized)
            return
        }
        if (!knownFile) { showWebPage(normalized); return }
        val detected = name.substringBeforeLast('.').replace('-', ' ').replace('_', ' ')
        AlertDialog.Builder(this).setTitle("Checking game name")
            .setMessage("Detected: ${detected.ifBlank { "Unknown game" }}\nFile type: .$ext\n\nAdd this download to your ZENX library?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Add & Download") { _, _ -> download(normalized, detected.ifBlank { name }, ext) }
            .show()
    }

    private fun download(link: String, name: String, ext: String) {
        try {
            val req = DownloadManager.Request(Uri.parse(link))
                .setTitle(name)
                .setDescription("Downloading with ZENX")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name.replace("/", "_"))
            val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(req)
            val obj = JSONObject().put("name", name).put("url", link).put("type", ext).put("status", "Downloading")
            items.put(obj); saveItems(); renderItems()
            toast("Download started. Some file-host links need their own download page.")
        } catch (e: Exception) { toast("Couldn't start download: ${e.message}") }
    }

    private fun showWebPage(link: String) {
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.loadUrl(link)
        val dialog = Dialog(this)
        val holder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16,21,34))
            addView(Button(this@MainActivity).apply { text = "CLOSE"; setOnClickListener { dialog.dismiss() } })
            addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        dialog.setContentView(holder)
        dialog.window?.setLayout(-1, -1)
        dialog.show()
        dialog.window?.setLayout(-1, -1)
    }

    private fun loadItems() {
        val saved = prefs.getString("games", "[]") ?: "[]"
        try {
            val arr = JSONArray(saved)
            for (i in 0 until arr.length()) items.put(arr.getJSONObject(i))
        } catch (_: Exception) {}
        renderItems()
    }

    private fun saveItems() { prefs.edit().putString("games", items.toString()).apply() }

    private fun renderItems() {
        list.removeAllViews()
        if (items.length() == 0) {
            list.addView(label("No games yet. Paste a supported direct download link above.", 15f, Color.LTGRAY))
        }
        for (i in 0 until items.length()) {
            val obj = items.getJSONObject(i)
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 12, 16, 12)
                setBackgroundColor(Color.rgb(35,43,62))
            }
            card.addView(label(obj.optString("name"), 18f, Color.WHITE))
            card.addView(label(obj.optString("type").uppercase() + " • " + obj.optString("status"), 12f, Color.LTGRAY))
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(Button(this).apply {
                text = "OPEN LINK"
                setOnClickListener {
                    val u = obj.optString("url")
                    if (obj.optString("type") == "apk") {
                        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
                        catch (_: Exception) { showWebPage(u) }
                    } else if (obj.optString("type") == "exe") {
                        toast("EXE files need a compatible Windows emulator; Android can't run them natively.")
                    } else showWebPage(u)
                }
            })
            actions.addView(Button(this).apply {
                text = "REMOVE"
                setOnClickListener {
                    val newer = JSONArray()
                    for (j in 0 until items.length()) if (j != i) newer.put(items.getJSONObject(j))
                    while (items.length() > 0) items.remove(0)
                    for (j in 0 until newer.length()) items.put(newer.getJSONObject(j))
                    saveItems(); renderItems()
                }
            })
            card.addView(actions)
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
